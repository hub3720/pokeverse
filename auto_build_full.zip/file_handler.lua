-- Manipulador de Arquivos

local HttpService = game:GetService("HttpService")

function LoadBuildFile(fileName)
    local filePath = "workspace/" .. fileName
    local fileContent = readfile(filePath)
    return HttpService:JSONDecode(fileContent)
end
