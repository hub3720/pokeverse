-- Script de Pré-Visualização

function PreviewBuild(buildData)
    for _, block in pairs(buildData) do
        local part = Instance.new("Part")
        part.Position = Vector3.new(unpack(block.Position:split(",")))
        part.Size = Vector3.new(unpack(block.Size:split(",")))
        part.Color = Color3.fromRGB(unpack(block.Color:split(",")))
        part.Anchored = true
        part.CanCollide = false
        part.Parent = game.Workspace
    end
end
