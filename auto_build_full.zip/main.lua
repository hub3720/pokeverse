-- Script Principal para Auto Build no Build A Boat For Treasure

loadstring(game:HttpGet("https://raw.githubusercontent.com/usuario/repositorio/main/ui.lua"))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/usuario/repositorio/main/file_handler.lua"))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/usuario/repositorio/main/preview.lua"))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/usuario/repositorio/main/auto_build.lua"))()
